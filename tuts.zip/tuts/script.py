if __name__ =="__main__":
    print("this is a main function in script")
else:
    print(__name__)